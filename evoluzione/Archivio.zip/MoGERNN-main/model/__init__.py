from model import MoGERNN
